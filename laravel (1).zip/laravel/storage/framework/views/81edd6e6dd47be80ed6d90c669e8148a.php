

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Registrar Usuario</h1>
    <form action="<?php echo e(route('usuario.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="idEmpleado">Empleado</label>
            <input type="number" class="form-control" id="idEmpleado" name="idEmpleado" required>
        </div>
        <div class="form-group">
            <label for="usuario">Usuario</label>
            <input type="text" class="form-control" id="usuario" name="usuario" required>
        </div>
        <div class="form-group">
            <label for="contrasenia">Contraseña</label>
            <input type="password" class="form-control" id="contrasenia" name="contrasenia" required>
        </div>
        <div class="form-group">
            <label for="idRol">Rol</label>
            <input type="number" class="form-control" id="idRol" name="idRol" required>
        </div>
        <button type="submit" class="btn btn-primary">Registrar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Curacao\Desktop\ProyectoDesWeb\papergeometry\resources\views/usuario/create.blade.php ENDPATH**/ ?>