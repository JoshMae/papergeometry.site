<link rel="stylesheet" href="<?php echo e(asset('css/Productos.css')); ?>"> 
<div class="producto-container">
    <?php if(!empty($productos) && count($productos) > 0): ?>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="producto">
                <img src="<?php echo e($producto['foto']); ?>" alt="<?php echo e($producto['nombre']); ?>">
                <h3><?php echo e($producto['nombre']); ?></h3>
                <p class="precio">Precio: Q. <?php echo e($producto['precio']); ?></p>
                <p class="descripcion"> <?php echo e($producto['detalle']); ?></p>
                <!-- Formulario de agregar al carrito -->
                <form class="form-agregar-carrito" action="<?php echo e(route('nuevoCarritoAgregar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="producto_id" value="<?php echo e($producto['idProducto']); ?>">
                    <input type="hidden" name="nombre" value="<?php echo e($producto['nombre']); ?>">
                    <input type="hidden" name="precio" value="<?php echo e($producto['precio']); ?>">
                    <input type="hidden" name="foto" value="<?php echo e($producto['foto']); ?>">
                    <input type="hidden" name="cantidad" value="1">
                    <button class="btn-agregar-carrito">Agregar al Carrito</button>    
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No hay productos disponibles en este momento.</p>
    <?php endif; ?>
</div>
<?php /**PATH /home/papergeo/laravel/resources/views/Productos/productos.blade.php ENDPATH**/ ?>