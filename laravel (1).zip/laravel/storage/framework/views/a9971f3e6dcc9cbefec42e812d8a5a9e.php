

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registrar Usuario</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('empleado.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="idEmpleado" class="form-label">Id Empleado</label>
            <input type="number" class="form-control" id="idEmpleado" name="idEmpleado" value="<?php echo e(old('idEmpleado')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="usuario" class="form-label">Nombre Usuario</label>
            <input type="text" class="form-control" id="usuario" name="usuario" value="<?php echo e(old('usuario')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="contrasenia" class="form-label">Contraseña</label>
            <input type="text" class="form-control" id="contrasenia" name="contrasenia" value="<?php echo e(old('contrasenia')); ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="idRol" class="form-label">Rol</label>
            <input type="number" class="form-control" id="idRol" name="idRol" value="<?php echo e(old('idRol')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Registrar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Curacao\Desktop\ProyectoDesWeb\papergeometry\resources\views/empleado/create.blade.php ENDPATH**/ ?>