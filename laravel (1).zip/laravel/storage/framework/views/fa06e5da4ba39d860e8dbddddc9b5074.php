<!-- resources/views/Bienvenida/index.blade.php -->


<?php $__env->startSection('title', 'Bienvenida'); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($mensajebienvendida); ?></h1>
    <p>¡Descubre el arte en tus manos, un cubo a la vez!</p>
    <h2><?php echo e($subproductosenoferta); ?></h2>

    <!-- Incluir la vista de productos -->
    <?php echo $__env->make('Productos.productos', ['productos' => $productos], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Pasamos la variable $productos -->

    <!-- Mensaje flotante de confirmación -->
    <div class="alerta-flotante" id="mensaje-flotante">
        ¡Producto agregado al carrito con éxito!
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('js/CarritoNuevo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/papergeo/laravel/resources/views/Bienvenida/index.blade.php ENDPATH**/ ?>