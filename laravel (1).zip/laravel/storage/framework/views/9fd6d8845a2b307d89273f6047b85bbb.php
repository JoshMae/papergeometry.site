<?php $__env->startSection('title', 'Ordenar'); ?>

<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/Ordenar.css')); ?>">

<h1>Confirmar Orden</h1>

<div class="flex-container"> 

    <form id="pagoForm" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="nuevo-bloque">
            <h2>Datos del cliente</h2>
            <div class="contenedor-datos-cliente">
                <input type="text" id="Nombre" name="nombre" placeholder="Nombre" >
                <small id="nombre-error" class="error-text"></small>
                <input type="text" id="Apellido" name="apellido" placeholder="Apellido" >
                <small id="apellido-error" class="error-text"></small>
                <input type="tel" name="Telefono" placeholder="Número de teléfono">       
                <small id="tel-error" class="error-text"></small>         
                <input type="correo" id="Correo" name="correo" placeholder="Ingresa tu correo electrónico" >
                <small id="correo-error" class="error-text"></small>
            </div>  
        </div>
        <label for="metodo_pago">Selecciona el método de pago:</label>
        <select id="metodo_pago" name="metodo_pago" required>
            <option value="">-- Selecciona --</option>
            <option value="tarjeta">Pago con Tarjeta</option>
            <option value="transaccion">Pago por Transacción</option>
        </select>
          
        <div id="formTransaccion" class="pago-opcion" style="display: none;">
            <h3>Información de Pago</h3>
            <div class="contenedor-transaccion">
                <input type="text" id="Cuenta" name="cuenta" placeholder="Ingresa tu cuenta" >  
                <small id="cuenta-error" class="error-text"></small>
                <input type="hidden" name="valor" id="totalCompra" value="<?php echo e(number_format($totalCarrito, 2, '.', '')); ?>">
                <button type="submit">Realizar Pago</button>
            </div>
        </div>

        <div id="formTarjeta" class="pago-opcion" style="display: none;">
            <h5>Información de Pago</h5>
            <div class="contener-tarjeta">
                <div class="input-grupo">
                    <input type="text" id="Tarjeta" name="tarjeta" placeholder="Ingresa la tarjeta" >
                    <small id="tarjeta-error" class="error-text"></small>
                </div>
                <div class="flex-row">
                    <div class="campo-exp-codigo">
                        <input type="text" id="Expiracion" name="expiracion" placeholder="MM/AA" >
                        <small id="expiracion-error" class="error-text"></small>
                    </div>
                    <div class="campo-codigo">
                        <input type="text" name="codigo_seg" id="codigoseg" placeholder="Código seguridad" >
                        <small id="codigoseg-error" class="error-text"></small>
                    </div>
                </div>
                <div class="input-grupo">
                    <input type="text" name="nombre_tarjeta" id="nombretarjeta" placeholder="Nombre de Titular" >
                    <small id="nombretarjeta-error" class="error-text"></small>
                </div>
                <button id="confirmarPago">Confirmar Pago</button>

                <div id="resultadoTransaccion" class="mt-4 alert" style="display: none;"></div>
            </div>
        </div>
    </form>

    <div class="container-resumen">
        <div class="resumen">
            <h3>Resumen de Pedido</h3>
            <?php $__currentLoopData = $productosEnCarrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="producto-item">
                <div class="imagen-contenedor">
                    <img src="<?php echo e($producto['foto']); ?>" alt="<?php echo e($producto['nombre']); ?>" class="producto-imagen">
                    <p class="cantidad-badge"><?php echo e($producto['cantidad']); ?></p>
                </div>
                <div class="producto-info">
                    <p class="producto-nombre"><?php echo e($producto['nombre']); ?></p>
                    <p class="producto-subtotal">Q<?php echo e(number_format($producto['precio'] * $producto['cantidad'], 2)); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="producto-final">
                <div class="subtotal-row">
                    <label>Subtotal:</label>
                    <label>Q<?php echo e(number_format($subtotal, 2)); ?></label>
                </div>
                <div class="total-row">
                    <label>Total:</label>
                    <label>Q<?php echo e(number_format($totalCarrito, 2)); ?></label>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/Validaciontarjeta.js')); ?>"></script>
<script src="<?php echo e(asset('js/Validaciontransaccion.js')); ?>"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    document.getElementById('metodo_pago').addEventListener('change', function() {
        const metodo = this.value;
        const formTarjeta = document.getElementById('formTarjeta');
        const formTransaccion = document.getElementById('formTransaccion');
    
        // Ocultar ambos formularios inicialmente
        formTarjeta.style.display = 'none';
        formTransaccion.style.display = 'none';
    
        // Limpiar errores al cambiar el método de pago
        limpiarMensajesDeError();
        resetearEstilosInputs();
    
        // Mostrar el formulario correspondiente
        if (metodo === 'tarjeta') {
            formTarjeta.style.display = 'block';
        } else if (metodo === 'transaccion') {
            formTransaccion.style.display = 'block';
        }
    });


    document.getElementById('pagoForm').addEventListener('submit', function(e) {
        e.preventDefault(); 
        
        if (!validarDatosCliente()) {
            return;
        }
        
        const formData = new FormData(this);
        const data = {
            cuenta: formData.get('cuenta'),
            terminal: '1',
            valor: formData.get('valor'),
            empresa: 'PaperGeometry'
        };
    
        // Obtener el token CSRF desde el meta tag
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    
        fetch('/api-proxy/cobropos', { // Ahora apunta al proxy de Laravel
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken // Añadir el token CSRF en los headers
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.text();
        })
        .then(result => {
            const resultadoElement = document.getElementById('resultadoTransaccion');
            resultadoElement.style.display = 'block';
            console.log(result);
            if (result === '1') {
                resultadoElement.className = 'mt-4 alert alert-success';
                resultadoElement.textContent = 'Transacción aprobada';
                alert('Transacción aprobada');
            } else if (result === '0') {
                resultadoElement.className = 'mt-4 alert alert-danger';
                resultadoElement.textContent = 'Transacción rechazada';
                alert('Transacción rechazada');
            } else {
                resultadoElement.className = 'mt-4 alert alert-warning';
                resultadoElement.textContent = 'Respuesta inesperada: ' + result;
                alert('Respuesta inesperada: ' + result);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const resultadoElement = document.getElementById('resultadoTransaccion');
            resultadoElement.style.display = 'block';
            resultadoElement.className = 'mt-4 alert alert-danger';
            resultadoElement.textContent = 'Error al procesar la transacción: ' + error.message;
        });
    });




</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/papergeo/laravel/resources/views/carrito/ordenar.blade.php ENDPATH**/ ?>