
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/Bienvenida.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- Header común -->
    <header>
        <div class="Logo">
            <a href="<?php echo e(url('/Bienvenida')); ?>">
            <img src="<?php echo e(asset('Img/7-Photoroom.png')); ?>" alt="Logo">
        </a>
        </div>
        <nav class="barranavegadora">
            <ul>
                <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li><a href="">Ofertas</a></li>
                <li><a href="">Productos</a></li>
                <li><a href="">Nosotros</a></li>
            </ul>
        </nav>
        
        <div class="BarraSearch">
            <input type="search" class="busqueda" placeholder="Buscar productos..." aria-label="Buscar productos">
            <button type="submit">
                <i class="fas fa-search"></i> 
            </button>

            <div class="Carrito">
                <a href="<?php echo e(url('/nuevo-carrito')); ?>">
                    <button class="carrito-button" id="boton-carrito">
                        <i class="fas fa-shopping-cart icono-carrito"></i>
                    </button>
                </a>
            </div>
            
        </div>
    </header>

    <div>
        
        <button id="boton-categoria">
            <i class="fas fa-bars"></i> Categorías
            <div id="menu-categorias" class="Menu-Categorias">
                <ul class="categorias">
                    <!-- Las categorías dinámicas se cargarán aquí -->
                </ul>
            </div>
        </button>
        
        
    </div>
    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer común -->
    <footer style="background-color: #333; color: #fff; padding: 20px 0; text-align: center;">
        <div>
            <p>&copy; 2024 Paper Geometry. Todos los derechos reservados.</p>
        </div>
        <div class="politicas">
            <p><a href="#">Política de Privacidad</a> | <a href="#">Términos y Condiciones</a></p>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/Categoria.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    
    <!-- Aquí podrías incluir scripts generales -->
    
</body>
</html>
<?php /**PATH /home/papergeo/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>