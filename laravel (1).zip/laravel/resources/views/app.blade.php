<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Mi Aplicación')</title>
    <!-- Agrega aquí tus archivos CSS -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color: #343a40;
            padding: 10px;
            color: #fff;
            text-align: center;
        }
        .navbar a {
            color: #fff;
            text-decoration: none;
            padding: 0 15px;
        }
        .navbar a:hover {
            text-decoration: underline;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="/">Inicio</a>
        <a href="/registrar-compra">Registrar Compra</a>
        <a href="/pedidos">Ver Pedidos</a>
    </div>

    <div class="container">
        @yield('content')
    </div>

    <!-- Agrega aquí tus archivos JS -->
    <script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
